package acervodelivro;

import java.util.ArrayList;
import javax.swing.JOptionPane;

//Classe para definição do Livro herdando a classe Usuario
public class Livro extends Usuario {
    
     //Atributos
    private int id;
    private String titulo;
    private String autor;
    private String edicao;
    private String editora;
    private String cidade;
    private int anopublicacao;
    
    //Métodos De Acesso Set
    public void setId(){
        this.id = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Informe o ID do livro: ","Cadastro",JOptionPane.QUESTION_MESSAGE));
    }
    
    public void setTitulo(){
        this.titulo = JOptionPane.showInputDialog(null,
                "Informe o título do livro: ","Cadastro",JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setAutor(){
        this.autor = JOptionPane.showInputDialog(null,
                "Informe o autor do livro: ","Cadastro",JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setEdicao(){
        this.edicao = JOptionPane.showInputDialog(null,
                "Informe a edição do livro: ","Cadastro",JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setEditora(){
        this.editora = JOptionPane.showInputDialog(null,
                "Informe a editora do livro: ","Cadastro",JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setCidade(){
        this.cidade = JOptionPane.showInputDialog(null,
                "Informe a cidade do livro: ","Cadastro",JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setAnoPublicacao(){
            anopublicacao = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Informe o ano de publicação: ","Cadastro",JOptionPane.QUESTION_MESSAGE));
        
            if(anopublicacao <=2020)
                this.anopublicacao = anopublicacao;
            else{
                this.anopublicacao = 0000;
                JOptionPane.showMessageDialog(null,"Ano inválido.","Cadastro",JOptionPane.ERROR_MESSAGE);
                
            }          
    }
    
     //Métodos De Acesso Get
   public int getId(){
       return this.id;
   }
   
   public String getTitulo(){
       return this.titulo;
   }
   
   public String getAutor(){
       return this.autor;
   }
   
   public String getEdicao(){
       return this.edicao;
   }
   
   public String getEditora(){
       return this.editora;
   }
    
   public String getCidade(){
       return this.cidade;
   }
   
   public int getAnoPublicacao(){
       return this.anopublicacao;
   }
   
   //Construtores
   
   //Construtor Padrão
   public Livro(){
       this.id = 0;
       this.titulo = "";
       this.autor = "";
       this.edicao = "";
       this.editora = "";
       this.anopublicacao = 0;
   }
   
   //Construtores Sobrecarregados -> Polimorfismo por Sobrecarga
   public Livro(int idlivro){
       setId();
       this.titulo = "";
       this.autor = "";
       this.edicao = "";
       this.editora = "";
       this.anopublicacao = 0;
   }
   
   public Livro(int idlivro, String titulo){
       setId();
       setTitulo();
       this.autor = "";
       this.edicao = "";
       this.editora = "";
       this.anopublicacao = 0;
   }
   
   public Livro(int idlivro, String titulo, String autor){
       setId();
       setTitulo();
       setAutor();
       this.edicao = "";
       this.editora = "";
       this.anopublicacao = 0;
   }
   
   public Livro(int idlivro, String titulo, String autor, String edicao){
       setId();
       setTitulo();
       setAutor();
       setEdicao();
       this.editora = "";
       this.anopublicacao = 0;
   }
   
   public Livro(int idlivro, String titulo, String autor, String edicao, String editora){
       setId();
       setTitulo();
       setAutor();
       setEdicao();
       setEditora();
       this.anopublicacao = 0;
   }
   
   public Livro(int idlivro, String titulo, String autor, String edicao, String editora, int anopublicacao){
       setId();
       setTitulo();
       setAutor();
       setEdicao();
       setEditora();
       setAnoPublicacao();
   }
   
   //Polimorfismo por Sobreposição
   @Override
   public String toString(){
       return 
          "ID: " + getId()
          + "\nTítulo: " + getTitulo()
          + "\nAutor: " + getAutor()
          + "\nEdição: " + getEdicao()
          + "\nEditora: " + getEditora()
          + "\nAno de Publicação: " + getAnoPublicacao()
       ;
   }
   
   //Método para Cadastrar Livro
   public void cadastrarLivro(ArrayList<Livro> livros, Livro livro){
       //Preenchimento das informações
       livro.setId();
       livro.setTitulo();
       livro.setAutor();
       livro.setEdicao();
       livro. setEditora();
       livro.setAnoPublicacao();
       livros.add(livro); //Adição à lista
   }
   
   //Método para buscar livro pelo ID
   public void buscarLivro(ArrayList<Livro> livros){
       int busca; //Atributo para armazenar o id do livro procurado
       int flag = 0; //Atributo para verificar se houve resultado
       
       busca = Integer.parseInt(JOptionPane.showInputDialog(null,
               "Informe o ID do livro: ","Busca",JOptionPane.QUESTION_MESSAGE));
       
       for(Livro l: livros){ //Loop para percorrer a lista de Livros
           if(l.getId() == busca){
               JOptionPane.showMessageDialog(null,
                       "Resultado\n" + l,"Busca",JOptionPane.INFORMATION_MESSAGE);
               flag++; 
           }
       }
       
       if(flag == 0){ //Verificação se houve resultado
           JOptionPane.showMessageDialog(null,
                   "Nenhum Resultado...","Busca",JOptionPane.ERROR_MESSAGE);
       }
   }
}
