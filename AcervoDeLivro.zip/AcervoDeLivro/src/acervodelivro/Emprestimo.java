package acervodelivro;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

//Classe para definição do Empréstimo herdando da classe Usuario
public class Emprestimo extends Usuario{
    
    //Atributos
    private int id;
    private int idUsuario;
    private int idLivro;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    private boolean devolvido = true; 
    
    //Formatação para data
    DateTimeFormatter data = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    //Métodos de Acesso Set
    public void setId(){
        this.id = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Informe o ID do empréstimo: ","Cadastro",JOptionPane.QUESTION_MESSAGE));
    }
    
    public void setIdUsuario(){
        this.idUsuario = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Informe o ID do usuário: ","Cadastro",JOptionPane.QUESTION_MESSAGE));
    }
    
    public void setIdLivro(){
        this.idLivro = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Informe o ID do livro: ","Cadastro",JOptionPane.QUESTION_MESSAGE));
    }
    
    public void setDataEmprestimo(){
        this.dataEmprestimo = LocalDate.now();
    }   
    
    public void setDataDevolucao(){
        this.dataDevolucao = LocalDate.now();
    }
    
    public void setDevolvido(){
        int opcao = Integer.parseInt(JOptionPane.showInputDialog(null,"1 - Empréstimo\n2 - Devolução\n\nInforme uma opção: ",
                    "Empréstimo",JOptionPane.QUESTION_MESSAGE));
        
        if(opcao == 1){
            this.devolvido = false;
        }
        else if(opcao == 2){
            this.devolvido = true;
        }
        else
            JOptionPane.showMessageDialog(null,"Opção Inválida...","Empréstimo",JOptionPane.ERROR_MESSAGE);
    }
    //Métodos de Acesso Get
    public int getId(){
        return this.id;
    }
    
    public int getIdUsuario(){
        return this.idUsuario;
    }
    
    public int getIdLivro(){
        return this.idLivro;
    }
    
    public String getDataEmprestimo(){
        String dataFormatada = dataEmprestimo.format(data);
        return dataFormatada;
    }
    
    public String getDataDevolucao(){
        String dataFormatada = dataDevolucao.format(data);
        return dataFormatada;
    }
    
    public boolean getDevolvido(){
        return this.devolvido;
    }
    
    //Construtores
    
    //Construtor Padrão
    public Emprestimo(){
        this.id = 0;
        this.idUsuario = 0;
        this.idLivro = 0;
        setDataEmprestimo();
        this.dataDevolucao = LocalDate.of(2020,1,1);
        this.devolvido = devolvido;
    }
    
    //Construtores Sobrecarregados -> Polimorfismo por Sobrecarga
    public Emprestimo(int id){
        setId();
        this.idUsuario = 0;
        this.idLivro = 0;
        setDataEmprestimo();
        this.dataDevolucao  = LocalDate.of(2020,1,1);
        this.devolvido = devolvido;
    }
    
    public Emprestimo(int id, int idUsuario){
        setId();
        setIdUsuario();
        this.idLivro = 0;
        setDataEmprestimo();
        this.dataDevolucao  = LocalDate.of(2020,1,1);
        this.devolvido = devolvido;
    }
    
    public Emprestimo(int id, int idUsuario, int idLivro){
        setId();
        setIdUsuario();
        setIdLivro();
        setDataEmprestimo();
        this.dataDevolucao  = LocalDate.of(2020,1,1);
        this.devolvido = devolvido;
    }
    
    //ToString -> Polimorfismo por Sobreposição 
   @Override
   public String toString(){
       
       if(devolvido == false){//Listagem de livros emprestados
           return "ID: " + getId()
                    +"\nId Usuário: " + getIdUsuario()
                    +"\nId Livro: " + getIdLivro()
                    +"\nData Empréstimo: " + getDataEmprestimo()
                    +"\nDevolvido: " + getDevolvido()
                    ;
       }
       else{
           return "ID: " + getId()
                    +"\nId Usuário: " + getIdUsuario()
                    +"\nId Livro: " + getIdLivro()
                    +"\nData Devolução: " + getDataDevolucao()
                    +"\nDevolvido: " + getDevolvido()
                    ;
       }
   }
   
   //Método para realizar empréstimo de Livro
   public void emprestarLivro(ArrayList<Emprestimo> emprestimos, Emprestimo emprestimo){
       
            
       //Entrada de dados do Empréstimo
        
        emprestimo.setDevolvido(); //Verifica se o livro está sendo emprestado ou devolvido
        if(emprestimo.getDevolvido() == false) //Caso esteja sendo emprestado
          emprestimo.setDataEmprestimo();  //Registra a data do empréstimo
        else //Caso esteja sendo devolvido
            emprestimo.setDataDevolucao(); //Registra a data da devolução
        
        emprestimo.setId(); //Registra o Id do empréstimo
        emprestimo.setIdUsuario(); //Registra o Id do usuário
        emprestimo.setIdLivro(); //Registra o Id do livro
        
        emprestimos.add(emprestimo); //Inserção na lista de empréstimo
        JOptionPane.showMessageDialog(null,"Empréstimo/Devolução realizado(a)","Empréstimo",JOptionPane.INFORMATION_MESSAGE);
    }
}       
       
             
       /* MÉTODO ALTERNATIVO PARA REALIZAÇÃO DE EMPRÉSTIMO
    
       /////////////////////////////////////////////////////////////////////////////////////////////////
       ESTE MÉTODO REALIZA O EMPRÉSTIMO DE FORMA MAIS ELABORADA,
       PRIMEIRAMENTE, VERIFICA-SE SE O LIVRO ESTÁ CADASTRADO NO ACERVO
       EM SEGUIDA, O USUÁRIO CONFIRMA SUA DECISÃO E INFORMA OS DADOS NECESSÁRIOS
       NESSE PROCESSO, OCORRE A VERIFICAÇÃO DO ID DO EMPRÉSTIMO, UMA VEZ QUE O MESMO DEVE SER ÚNICO
       FEITO ISSO, O LIVRO É EMPRESTADO E TEM SEU STATUS ATUALIZADO, APARECENDO NA LISTA DE NÃO DEVOLVIDOS.
       
       OBS: O MÉTODO ESTÁ INCOMPLETO, POIS FALA A FUNÇÃO DE DEVOLUÇÃO DO LIVRO,
       A QUAL DEVE MUDAR O STATUS DO EMPRESTIMO PARA TRUE, LISTANDO-O NOS DEVOLVIDOS
       
       OBS2: PARA UTILIZAÇÃO DESSE MÉTODO É NECESSÁRIO RECEBER OS SEGUINTES ATRIBUTOS:
       ArrayList<Emprestimo> emprestimos, Emprestimo emprestimo,ArrayList<Livro> livros
   
       E O MÉTODO setDevolvido DEVE REALIZAR A SEGUINTE AÇÃO:
       this.devolvido = false;
       
       /////////////////////////////////////////////////////////////////////////////////////////////////
       
       int opcao; //Variável para seleção de opção
       int flag = 0; //Variável para verificar se houve resultado
       boolean check = false; //Variável para verificar a disponibilidade do livro
      //Variável para armazenar o nome do livro a ser buscado     
      String busca = JOptionPane.showInputDialog(null,
               "Informe o nome do livro que deseja emprestar: ","Empréstimo", JOptionPane.QUESTION_MESSAGE);
       
       for(Livro l: livros){ //Verificar se o livro existe nos registros
           if(l.getTitulo().equals(busca)){ //Caso exista
               
           flag++;//Atribuição de resultado
                
               //Entrada de dados da confirmação do empréstimo
               String resp = JOptionPane.showInputDialog(null,
                       "Deseja realizar o empréstimo do livro " + l.getTitulo() + " <S/N>?",
                       "Empréstimo", JOptionPane.QUESTION_MESSAGE);
               
               //Processamento da confirmação
               if(resp.toUpperCase().equals("S")){ //Caso a resposta for SIM 
                   
                   //Entrada de dados do Empréstimo
                   emprestimo.setId();
                   
                   //Verificação de disponibilidade
                   for (Emprestimo e: emprestimos){ //Percorre a lista d livro emprestados
                       if(emprestimo.getId() == e.getId()){ //Verifica se o Id inserido já está em uso
                           JOptionPane.showMessageDialog(null,"ID de empréstimo já cadastrado...","Empréstimo",JOptionPane.ERROR_MESSAGE);  
                           check = true; //Impede o empréstimo caso o Id esteja em uso
                       }                              
                   }
                        if(check == false){ //Permite o empréstimo caso o Id esteja disponível
                   
                        emprestimo.setIdUsuario();
                        emprestimo.setIdLivro();
                        emprestimo.setDataEmprestimo();
                        emprestimo.setDevolvido();

                        emprestimos.add(emprestimo); //Inserção na lista de empréstimo
                        JOptionPane.showMessageDialog(null,"Empréstimo realizado","Empréstimo",JOptionPane.INFORMATION_MESSAGE);
                   }                   
                }
                else{//Caso a resposta for NÃO
                    JOptionPane.showMessageDialog(null,"Empréstimo Cancelado...","Empréstimo",JOptionPane.INFORMATION_MESSAGE);
                }

            }
        
        }
            
            if(flag == 0){ //Caso não exista resultado
               JOptionPane.showMessageDialog(null,
                       "Livro Inexistente...","Empréstimo",JOptionPane.ERROR_MESSAGE);
            }
      */  