package acervodelivro;
 // @author Gustavo
 
import static java.lang.System.exit;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

//Classe para a execução do programa
public class AcervoDeLivro {

    public static void main(String[] args) { //Função Principal
        
        int controle; //Atributo para controle do menu
        
        //Listas
         List<Usuario> usuarios = new ArrayList<>(); // Cria Lista de Usuários
         List<Livro> livros = new ArrayList<>();    //Cria Lista de Livros
         List<Emprestimo> emprestimos = new ArrayList<>();  //Cria Lista de Empréstimos
        
        //Menu
        do
        {
            controle = Integer.parseInt(JOptionPane.showInputDialog(
            null,
            "1)Adicionar novo Usuário.\n2)Pesquisar usuário.\n3)Listar usuários.\n" +
            "4)Adicionar livro.\n5)Pesquisar livro.\n6)Listar livros.\n" +
            "7)Realizar empréstimo/Devolução.\n8)Listas livros não devolvidos.\n9)Listar livros devolvidos.\n" +
            "10)Demonstração Polimorfismo\n0)Sair.\n" +
            "\nInforme uma opção: ",
            "Menu", JOptionPane.QUESTION_MESSAGE));
            
            switch(controle)
            {
                case 1:{ //Cadastro de Usuário
                    Usuario user = new Usuario(); //Cria objeto usuário
                        user.cadastroUsuario((ArrayList<Usuario>) usuarios,user);
                    break;
                }
                case 2:{ //Busca de usuário por nome
                    Usuario user = new Usuario(); //Cria objeto usuário
                    user.buscarUsuario((ArrayList<Usuario>) usuarios, user);
                    break;
                }
                case 3:{ //Listar todos os usuários
                        for(Usuario u: usuarios){ //Percorre a lista de usuários
                        System.out.println(u + "\n");
                        }   
                  break;
                }
                case 4:{ //Cadastrar livro
                    Livro livro = new Livro(); //Cria objeto Livro
                    livro.cadastrarLivro((ArrayList<Livro>) livros, livro);
                    break;
                }
                case 5:{ //Busca de livro pelo Id
                    Livro livro = new Livro(); //Cria obejto Livro
                    livro.buscarLivro((ArrayList<Livro>) livros);
                    break;
                }
                case 6:{ //Listar todos os livros
                        for(Livro l: livros){ //Percorre a lista Livro
                        System.out.println(l + "\n");
                        }  
                    break;
                }
                case 7:{ //Realizar empréstimo de livro
                    Emprestimo emprestimo = new Emprestimo(); //Cria objeto Empréstimo
                    emprestimo.emprestarLivro((ArrayList<Emprestimo>) emprestimos, emprestimo);
                    break;
                }
                case 8:{ //Listar livros não devolvidos
                        for(Emprestimo e: emprestimos){ //Loop para percorrer a lista de Empréstimos
                            if(e.getDevolvido() == false) //Verificação de devolução do livro
                                System.out.println(e + "\n"); //Impressão caso o livro não foi devolvido
                        }                  
                    break;
                }
                case 9:{ //Listar livros devolvidos
                        for(Emprestimo e: emprestimos){ //Loop para percorrer a lista de Empréstimos
                            if(e.getDevolvido() == true) //Verificação de devolução do livro
                                System.out.println(e + "\n"); //Impressão caso o livro já foi devolvido
                        }                  
                    break;
                }
                case 10:{ //Demonstração das funcionalidades (Construtotes + polimorfismo for generalização)
                    
                    //Polomorfismo por Generalização
                    System.out.println("POLIMORFISMO POR GENERALIZAÇÃO");
                    List<Usuario> testes = new ArrayList<>(); //Lista com 2 objetos Usuario, 1 objeto Livro e 1 objeto Emprestimo
                    testes.add(new Usuario()); //Cria objeto Usuário
                    testes.add(new Usuario(1,"Gustavo")); //Cria objeto Usuário
                    testes.add(new Livro()); //Cria objeto Livro
                    testes.add(new Emprestimo()); //Cria objeto Empréstimo
                    
                    for(Usuario u: testes)
                        System.out.println(u + "\n");
                      
                }
                case 0: exit(0); //Fechar programa
                default:{ //Caso de opção inválida
                    JOptionPane.showMessageDialog(null,"Opção Inválida...","Erro",JOptionPane.ERROR_MESSAGE);
                    break;
                }
            }// Fim do Switch
        }while(controle != 0); //Fim do Menu
        
    } //Fim da Main       
           
} //Fim da Classe





