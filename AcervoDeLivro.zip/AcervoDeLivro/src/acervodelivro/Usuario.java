package acervodelivro;

import java.util.ArrayList;
import javax.swing.JOptionPane;

//Classe para definição do Usuário herdando a classe abstrada User
public class Usuario extends User{
    
    //Atributos
    private int id;
    private String nome;
    private String email;
    private String senha;
    
    //Métodos De Acesso Set
    public void setId(){
         this.id = Integer.parseInt(JOptionPane.showInputDialog(null,
               "Informe o ID: ","Cadastro",JOptionPane.QUESTION_MESSAGE));
    }
    
    public void setNome(){
        this.nome = JOptionPane.showInputDialog(null,
                "Informe o nome: ","Cadastro",JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setEmail(){
        this.email = JOptionPane.showInputDialog(null,
                "Informe o E-mail: ","Cadastro",JOptionPane.QUESTION_MESSAGE);
    }
    
    public void setSenha(){
        this.senha = JOptionPane.showInputDialog(null,
                "Informe a senha: ","Cadastro",JOptionPane.QUESTION_MESSAGE); 
    }
    
   //Polimorfismo por Sobreposição
   @Override
   //Métodos De Acesso Get
   public int getId(){
       return this.id;
   }
   
    @Override  //Polimorfismo por Sobreposição
   public String getNome(){
       return this.nome;
   }
   
    @Override  //Polimorfismo por Sobreposição
   public String getEmail(){
       return this.email;
   }
   
    @Override  //Polimorfismo por Sobreposição
   public String getSenha(){
       return this.senha;
   }
   
   //Construtores
   
   //Construtor Padrão
   public Usuario(){
       this.id = 0;
       this.nome = "";
       this.email = "";
       this.senha = "";
   }
   
   //Construtores Sobrecarregados -> Polimorfismo por Sobrecarga
   public Usuario(int id){
       setId();
       this.nome = "";
       this.email = "";
       this.senha = "";
   }
   
   public Usuario(int id, String nome){
       setId();
       setNome();
       this.email = "";
       this.senha = "";
   }  
   
   public Usuario(int id, String nome, String email){
       setId();
       setNome();
       setEmail();
       this.senha = "";
   }
   
   public Usuario(int id, String nome, String email, String senha){
       setId();
       setNome();
       setEmail();
       setSenha();
   }
   
   //ToString Polimorfismo por Sobreposição
   @Override
   public String toString(){
       return 
        super.toString() + " (Usuário)" //Polimorfismo por Sobreposição
        + "\nNome: " + getNome()
        + "\nE-mail: " + getEmail()
        + "\nSenha: " + getSenha()
       ;
   } 
   
   //Método para cadastrar novo Usuário
    public void cadastroUsuario(ArrayList<Usuario> usuarios, Usuario user){
        
        //Prenchimento das informações
        user.setId();
        user.setNome();
        user.setEmail();
        user.setSenha();
            
        usuarios.add(user); //Adiciona à lista 
        
    }
    
    //Método para buscar usuário pelo nome
    public void buscarUsuario(ArrayList<Usuario> usuarios, Usuario user){
       
     int flag = 0;   //Variável para verificar resultado
     String busca = JOptionPane.showInputDialog(null, //Usuário a ser buscado
                "Informe o Nome do usuário: ", "Busca", JOptionPane.QUESTION_MESSAGE);
        
        for (Usuario u: usuarios){ //Percorre a lista de usuários
            if(u.getNome().equals(busca)){ //Verifica se o nome existe
                JOptionPane.showMessageDialog(null, //Mostra o resultado
                        "Resultado\n" + u,
                        "Busca", JOptionPane.INFORMATION_MESSAGE);
                        flag++; //Acrescenta resultado
            }   
        }
           
            if(flag == 0){ //Caso não haja resultado
                JOptionPane.showMessageDialog(null, //Informa o usuário
                        "Nenhum Resultado...",
                        "Busca", JOptionPane.ERROR_MESSAGE);
            }               
    }
}     
    
   

