package acervodelivro;

//Classe abstrata para criação do Usuário
public abstract class User {
    
    //Métodos obrigatórios para a classe Usuário
    public abstract int getId(); //Registro do Id
    public abstract String getNome(); //Registro do nome
    public abstract String getEmail(); //Registra o email
    public abstract String getSenha(); //Registra a senha
    
    @Override
    public String toString(){
    return "ID: " + getId();
    }
}
